import React from 'react';
import './App.css';
import Clock from './Components/Clock';

function App() {
  return <Clock />;
}

export default App;
