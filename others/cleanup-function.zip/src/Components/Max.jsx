import React from 'react'

export default function Max({ max }) {
    return (
        <div>
            Max: {max}
        </div>
    )
}
