import React from 'react';
import ReactDOM from 'react-dom';
import './style.css';
import Root from './Components/Root'

ReactDOM.render(
  <Root />
  ,
  document.getElementById('root')
);