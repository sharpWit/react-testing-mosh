import React from 'react';
import SignUp from './Components/SingUp'
import './style.css';


function App() {
  return (
    <SignUp />
  );
}

export default App;
