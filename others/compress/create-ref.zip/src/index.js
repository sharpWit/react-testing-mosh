import React from 'react';
import ReactDOM from 'react-dom';
import './style.css';
import Login from './Login'

ReactDOM.render(
  <Login />,
  document.getElementById('root')
);