import React from 'react'

export default function Arrrow() {
    return (
        <div className="arrow-wrapper">
            <div className="round">
                <div id="cta">
                    <span className="arrow prev"></span>
                </div>
            </div>
        </div>
    )
}
