import React, { Component } from 'react'
import TextInput from './TextInput'

export default class App extends Component {
  render() {
    return (
      <>
        <TextInput />
        <TextInput />
        <TextInput />
      </>
    )
  }
}
