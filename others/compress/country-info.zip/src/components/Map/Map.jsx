import React from 'react'
import map from './coords.json'
import ImageMapper from 'react-image-mapper';
import world from './map.jpg'

export default function Map() {
    return (
        <ImageMapper src={world} map={map} />
    )
}
