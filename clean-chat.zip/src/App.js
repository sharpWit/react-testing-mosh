import React from 'react';
import './App.css';
import CleanChat from './Components/CleanChat'
function App() {
    return <CleanChat />
}

export default App;
