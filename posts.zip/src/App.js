import React from 'react'
import './style.css'
import BlogPost from './Components/BlogPost'

function App() {
  return <BlogPost />
}

export default App;
